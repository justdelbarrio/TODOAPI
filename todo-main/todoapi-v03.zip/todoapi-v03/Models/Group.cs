﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TodoApi.Models
{
    [Table("groups", Schema = "todoapp")]
    public class Group
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Descrizione { get; set; }
    }
}